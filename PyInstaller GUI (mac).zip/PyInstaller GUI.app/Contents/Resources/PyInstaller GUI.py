from tkinter import *
import os
import subprocess
import webbrowser

root = Tk()
root.geometry('600x500')
root.title('PyInstaller GUI')

title = Label(root, text='PyInstaller GUI', font=('*', 25), padx=15, pady=15)
title.pack()

pipFrame = Frame(root, padx=15, pady=15)
pipFrame.pack()

pipVar = IntVar()
pip3Var = IntVar()
pipCheck = Checkbutton(pipFrame, text='pip', variable=pipVar)
pipCheck.pack(side=LEFT)
pipCheck3 = Checkbutton(pipFrame, text='pip3', variable=pip3Var)
pipCheck3.pack(side=LEFT)

def newWin(geoStr, showTitle, Lab1Str):
    newWin = Toplevel()
    newWin.geometry(geoStr)
    winTitleLab = Label(newWin, text=showTitle, padx=5, pady=5)
    winTitleLab.pack()
    winLab1 = Label(newWin, text=Lab1Str, padx=5, pady=5)
    winLab1.pack()

def installPyInstaller():
    if str(pipVar.get()) == '1' and str(pip3Var.get()) == '1':
        newWin('350x200', 'Error:', 'pip and pip3 are both selected')
    elif str(pipVar.get()) == '0' and str(pip3Var.get()) == '0':
        newWin('350x200', 'Error:', 'Neither pip nor pip3 are selected')
    elif str(pipVar.get()) == '1' and str(pip3Var.get()) == '0':
        os.system('pip install pyinstaller')
        newWin('350x200', 'Successfully installed PyInstaller', '')
    elif str(pipVar.get()) == '0' and str(pip3Var.get()) == '1':
        os.system('pip3 install pyinstaller')
        newWin('350x200', 'Successfully installed PyInstaller', '')

def dirQuestionFunc():
    dirPath = Toplevel()
    dirPath.geometry('350x200')
    dirPathTitle = Label(dirPath, text='Python File Path:', padx=5, pady=5)
    dirPathTitle.pack()
    dirPathExample = Label(dirPath, text='/directory/file.py', padx=5, pady=5)
    dirPathExample.pack()
    dirPathLab = Label(dirPath, text='(Starts from where this app is located)', padx=5, pady=5, fg='#FF0000')
    dirPathLab.pack()

def oneFileQuestionFunc():
    newWin('400x200', 'What is \"One file\"?', 'This will compile your program into one .exe file')
    
def noConsoleQuestionFunc():
    newWin('400x200', 'What is \"No console\"?', 'This will not launch the command line for your program\nLeave this unchecked if you\'re making a command line app')

def iconQuestionFunc():
    newWin('400x200', 'Custom icon format:', 'iconfile.ico')

def dataQuestionFunc():
    def whatIsData():
        webbrowser.open_new_tab('https://pyinstaller.readthedocs.io/en/stable/spec-files.html#adding-data-files')
    data = Toplevel()
    data.geometry('400x200')
    dataTitle = Label(data, text='Add data format:', padx=5, pady=5)
    dataTitle.pack()
    dataExample = Label(data, text='source.file;dest', padx=5, pady=5)
    dataExample.pack()
    dataWhatis = Button(data, text='What is adding data?', command=whatIsData)
    dataWhatis.pack()


def runPyInstaller():
    noRun = False

    filePathStr = str(dirPath.get())

    oneFile = str(oneFileVar.get())

    noConsole = str(noConsoleVar.get())

    iconPathCheck = str(iconVar.get())
    iconPathStr = str(iconPath.get())

    addDataCheck = str(dataVar.get())
    addDataFilesStr = str(dataIn.get())

    '''
    print(f"File path: {filePathStr}")
    print(f"One file check: {oneFile}")
    print(f"No console check: {noConsole}")
    print(f"Icon path check: {iconPathCheck}")
    print(f"Icon path: {iconPathStr}")
    print(f"Add data check: {addDataCheck}")
    print(f"Data files: {addDataFilesStr}")
    '''

    runList = ['pyinstaller']
    if filePathStr:
        runList.append(filePathStr)
    else:
        newWin('350x200', 'Error', 'No .py file entered')
        noRun = True
    if oneFile == '1':
        runList.append('--onefile')
    if noConsole == '1':
        runList.append('--noconsole')
    if iconPathCheck == '1':
        if iconPathStr:
            runList.append('--icon=' + iconPathStr)
        else:
            noRun = True
            newWin('350x200', 'Error:', 'No icon file entered')

    if addDataCheck == '1':
        if addDataFilesStr:
            runList.append('--add-data')
            runList.append(addDataFilesStr)
        else:
            noRun = True
            newWin('350x200', 'Error:', 'No data files entered')

    if noRun == False:
        newWin('500x150', 'Running in terminal:', runList)

        subprocess.call(runList)

checksFrame = Frame(root, padx=20, pady=20)
checksFrame.pack()

dirPathFrame = Frame(checksFrame, padx=5, pady=5)
dirPathFrame.pack()
dirPathLab = Label(dirPathFrame, text='.py File Path')
dirPathLab.pack(side=LEFT)
dirPath = Entry(dirPathFrame)
dirPath.pack(side=LEFT)
dirQuestion = Button(dirPathFrame, text='?', command=dirQuestionFunc, width=1)
dirQuestion.pack()


oneFileFrame = Frame(checksFrame, padx=5, pady=5)
oneFileFrame.pack()
oneFileVar = IntVar()
oneFileCheck = Checkbutton(oneFileFrame, text='One file', variable=oneFileVar)
oneFileCheck.pack(side=LEFT)
oneFileQuestion = Button(oneFileFrame, text='?', command=oneFileQuestionFunc, width=1)
oneFileQuestion.pack(side=LEFT)

noConsoleFrame = Frame(checksFrame, padx=5, pady=5)
noConsoleFrame.pack()
noConsoleVar = IntVar()
noConsoleCheck = Checkbutton(noConsoleFrame, text='No console', variable=noConsoleVar)
noConsoleCheck.pack(side=LEFT)
noConsoleQuestion = Button(noConsoleFrame, text='?', command=noConsoleQuestionFunc, width=1)
noConsoleQuestion.pack(side=LEFT)

iconFrame = Frame(checksFrame, padx=5, pady=5)
iconFrame.pack()
iconVar = IntVar()
iconCheck = Checkbutton(iconFrame, text='Custom icon   ', variable=iconVar)
iconCheck.pack(side=LEFT)
iconLab = Label(iconFrame, text='Icon path:\n(from directory)')
iconLab.pack(side=LEFT)
iconPath = Entry(iconFrame, width=10)
iconPath.pack(side=LEFT)
iconQuestion = Button(iconFrame, text='?', command=iconQuestionFunc, width=1)
iconQuestion.pack(side=LEFT)

dataFrame = Frame(checksFrame, padx=5, pady=5)
dataFrame.pack()
dataVar = IntVar()
dataCheck = Checkbutton(dataFrame, text='Add data files   ', variable=dataVar)
dataCheck.pack(side=LEFT)
dataLab = Label(dataFrame, text='Data files:')
dataLab.pack(side=LEFT)
dataIn = Entry(dataFrame, width=10)
dataIn.pack(side=LEFT)
dataQuestion = Button(dataFrame, text='?', command=dataQuestionFunc, width=1)
dataQuestion.pack(side=LEFT)

runPyInstaller = Button(checksFrame, text='Run PyInstaller', command=runPyInstaller)
runPyInstaller.pack()


installBtn = Button(pipFrame, text='Install PyInstaller', command=installPyInstaller)
installBtn.pack(side=LEFT)

creditFrame = Frame(root, padx=10, pady=10)
creditFrame.pack()

creditLab1 = Label(creditFrame, text='PyInstaller GUI for Windows')
creditLab2 = Label(creditFrame, text='Made by: Jason')
creditLab3 = Label(creditFrame, text='This app is not associated with PyInstaller')
creditLab1.pack()
creditLab2.pack()
creditLab3.pack()

root.mainloop()